package com.rajdroid.forinternship

object Utils {

    var gestDesc : ArticlesItem? = null
}